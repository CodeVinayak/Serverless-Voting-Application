export const GET_ALL_VOTES_URL =" https://x2zghxrgw9.execute-api.us-east-1.amazonaws.com/stage/vote"
export const GET_LANGUAGE_INFO_URL = "https://x2zghxrgw9.execute-api.us-east-1.amazonaws.com/stage/language"
export const VOTE_COUNT_UPDATE_URL = "https://x2zghxrgw9.execute-api.us-east-1.amazonaws.com/stage/update-vote"
